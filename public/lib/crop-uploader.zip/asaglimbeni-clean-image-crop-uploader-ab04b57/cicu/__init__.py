"""Clean Image Crop Uploader (CICU) provides AJAX file upload and image CROP functionalities for ImageFields with a simple widget replacement in the form."""

VERSION = (0, 2, 2)

__version__ = '.'.join(map(str, VERSION))
